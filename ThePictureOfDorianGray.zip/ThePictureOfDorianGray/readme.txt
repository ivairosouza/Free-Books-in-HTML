Hi There
My name Ivair
This is a HTML Book, HTML format is the smallest format to create a book.
I took this book from Guternberg.org, where there are more than 70.000 books 
in some formats, like online, EPUB3, EPUB, KINDLE and HTML.
You can saw the same HTML book there, but While exploring the HTML books, I 
noticed they had small text, excessive side margins, and a minimal design, 
making them harder to read. I decided to edit these books to improve their
 readability and make them more user-friendly.
 HTML file must be open with your Internet Browser, like Chrome.
 If you find there a book that interest you, and you think it's difficult to
 read, massege me, I can edit it to you.
 Enjoy your reading.